<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>

<!-- Navigation -->
<?php  include "includes/navigation.php"; ?>

<?php 


/*

mail ( string $to , string $subject , string $message [, mixed $additional_headers [, string $additional_parameters ]] ) : bool


$to      = 'nobody@example.com';
$subject = 'the subject';
$message = 'hello';
$headers = array(
    'From' => 'webmaster@example.com',
    'Reply-To' => 'webmaster@example.com',
    'X-Mailer' => 'PHP/' . phpversion()
);

mail($to, $subject, $message, $headers);

**/



// It Will work When YOU Upload Your Website
if(isset($_POST['submit'])){

    $to = "masterprog303@gmail.com";
    $subject = $_POST['subject'];
    $message = wordwrap($_POST['body'],70);
    $user_email = $_POST['user_email'];

    $headers = array(
    'From' => $user_email,
    'Reply-To' => $to,
    'X-Mailer' => 'PHP/' . phpversion()
);

    mail($to, $subject, $message, $headers);

}
?>

<!-- Page Content -->
<div class="container">

<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Contact Us</h1>
                    <form role="form" action="" method="post" id="login-form" autocomplete="off">

                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="user_email" id="email" class="form-control" placeholder="Enter Your Email">
                        </div>

                        <div class="form-group">
                            <label for="subject" class="sr-only">Subject</label>
                            <input type="text" name="subject" id="subject" class="form-control" placeholder="Enter Your Subject">
                        </div>
                         <div class="form-group">
                            <label for="body" class="sr-only">Enter Your Message</label>
                            <textarea class="form-control" name="body" id="body" cols="30" rows="10">
                                
                            </textarea>
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Send">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


    <hr>



<?php include "includes/footer.php";?>
