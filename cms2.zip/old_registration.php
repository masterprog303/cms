<?php  include "includes/db.php"; ?>
<?php  include "includes/header.php"; ?>

<!-- Navigation -->
<?php  include "includes/navigation.php"; ?>

<?php 

if(isset($_POST['submit'])){

    $user_name = $_POST['user_name'];
    $user_password = $_POST['user_password'];
    $user_email = $_POST['user_email'];

    // Validate Not Empty Fields
    if(!empty($user_name) && !empty($user_password) && !empty($user_email)){

        //===================IMPORTANT==========================================
        // ============ CLEAN DATA TO AVOID HACKERS ============================
        $user_name = mysqli_real_escape_string($connection, $user_name);
        $user_password = mysqli_real_escape_string($connection, $user_password);
        $user_email = mysqli_real_escape_string($connection, $user_email);
        //======================================================================
        
        
        // Bringing Salt From DATABASE
        $query = "SELECT rand_salt FROM users";
        $select_randsalt_query = mysqli_query($connection, $query);

        if(!$select_randsalt_query){ die("Query Failed" . mysqli_error($connection)); }

        $row = mysqli_fetch_array($select_randsalt_query);
        $salt = $row['rand_salt'];

        //===================IMPORTANT==========================================
        // ============ PASSWORD CRYPTING TO MORE SECURE =======================
        $user_password = crypt($user_password, $salt);
        //======================================================================

        $query = "INSERT INTO users (user_name, user_email, user_password, user_role) ";
        $query .= "VALUES ('{$user_name}', '{$user_email}', '{$user_password}', 'subscriber') ";

        $register_new_user_query = mysqli_query($connection, $query);

        if(!$register_new_user_query){ die("Query Failed" . mysqli_error($connection) . mysqli_errno($connection)); }

        //END MESSAGE
        $alert_class = "alert-success";
        $message = "Registeration Submitted";

    }else {

        $alert_class = "alert-danger";
        $message = "Fields Can't Be Empty";
        echo"<script> alert($message) </script>";

    }

}

?>

<!-- Page Content -->
<div class="container">

<section id="login">
    <div class="container">
        <div class="row">
            <div class="col-xs-6 col-xs-offset-3">
                <div class="form-wrap">
                <h1>Register</h1>
                    <form role="form" action="registration.php" method="post" id="login-form" autocomplete="off">

                        <h4 class="text-center alert <?php echo $alert_class; ?>"><?php if(isset($message)){echo $message;} ?></h4>

                        <div class="form-group">
                            <label for="username" class="sr-only">username</label>
                            <input type="text" name="user_name" id="username" class="form-control" placeholder="Enter Desired Username">
                        </div>
                         <div class="form-group">
                            <label for="email" class="sr-only">Email</label>
                            <input type="email" name="user_email" id="email" class="form-control" placeholder="somebody@example.com">
                        </div>
                         <div class="form-group">
                            <label for="password" class="sr-only">Password</label>
                            <input type="password" name="user_password" id="key" class="form-control" placeholder="Password">
                        </div>
                
                        <input type="submit" name="submit" id="btn-login" class="btn btn-custom btn-lg btn-block" value="Register">
                    </form>
                 
                </div>
            </div> <!-- /.col-xs-12 -->
        </div> <!-- /.row -->
    </div> <!-- /.container -->
</section>


    <hr>



<?php include "includes/footer.php";?>
