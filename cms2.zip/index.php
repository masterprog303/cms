<!--Connect To database-->
<?php include "includes/db.php" ?>

<!-- Header -->
<?php include "includes/header.php" ?>

<!-- Navigation -->

<?php include "includes/navigation.php" ?>

<!-- Page Content -->
<div class="container">

 <!-- Start row -->
<div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-8">

        <?php

        //LIMIT POSTS PER PAGES 

            if(isset($_GET['page'])){

                $page_number = $_GET['page'];
                
            } else {

                $page_number = 1;
            }

            $calc_post_count = "SELECT * FROM posts WHERE post_status = 'published' ";
            $result = mysqli_query($connection, $calc_post_count);
            $total_posts_count = mysqli_num_rows($result);
            
            $posts_per_page = 3;
            $number_of_seen_posts = $posts_per_page * ($page_number - 1);

            // clac num pages you need for pagination // 10 / 3 = 4 
            $number_of_pages = ceil($total_posts_count / $posts_per_page);


            $query = "SELECT * FROM posts WHERE post_status = 'published' LIMIT $number_of_seen_posts, $posts_per_page";

            $select_all_posts_query = mysqli_query($connection, $query);

            while($row = mysqli_fetch_assoc($select_all_posts_query)) {
                $post_id = $row['post_id'];
                $post_title = $row['post_title'];
                $post_user = $row['post_user'];
                $post_date = $row['post_date'];
                $post_image = $row['post_image'];
                $post_content = substr($row['post_content'], 0, 200) . "......"; // grap small content
                $post_status = $row['post_status'];

        ?>
                
                <h1 class="page-header">
                    Page Heading
                    <small>Secondary Text</small>
                </h1>

                <!-- First Blog Post -->
                <h2>
                    <a href="post.php?p_id=<?php echo $post_id; ?>"> <?php echo $post_title; ?> </a>
                </h2>

                <?php 
              
              $query = "SELECT user_name,user_id FROM users WHERE user_id = '$post_user' ";
              $select_users_query = mysqli_query($connection, $query);
              $row = mysqli_fetch_assoc($select_users_query);
              $post_user_id = $row['user_id'];
              $post_user_name = $row['user_name']; 

                 ?>


                <p class="lead">
                    by <a href="post_user.php?user=<?php echo $post_user; ?>"> <?php echo $post_user_name; ?> </a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post_date; ?> </p>
                <hr>

                <a href="post.php?p_id=<?php echo $post_id; ?>"> 

                    <img class="img-responsive" src="images/<?php echo $post_image; ?>" alt="">

                </a>

                <hr>
                <p> <?php echo $post_content; ?> </p>
                <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
            
            <?php } ?>

    </div>

    <!-- Blog Sidebar Widgets Column -->
    <?php include "includes/sidebar.php" ?>

</div>
<!-- /.row -->

<hr>

<ul class="pager">

    <li><a href='index.php?page=1'>First</a></li>

    <?php 

    for($i = 1; $i <= $number_of_pages ;$i++){

        if($i == $page_number){

            echo "<li><a class='active_link' href='index.php?page={$i}'>{$i}</a></li>";

        }else{

            echo "<li><a href='index.php?page={$i}'>{$i}</a></li>";
        }
    }
     ?>

     <li><a href='index.php?page=<?php echo $number_of_pages; ?>'>Last</a></li>


</ul>

<!-- Footer -->
<?php include "includes/footer.php" ?>