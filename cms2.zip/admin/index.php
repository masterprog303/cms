<!-- Header -->
<?php include "includes/admin_header.php" ?>

<div id="wrapper">

<!-- Navigation -->
<?php include "includes/admin_navigation.php" ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Welcome to Admin

                    <small>  <?php echo $_SESSION['user_name']; ?>   </small>
                </h1>
               
            </div>
        </div>
        <!-- /.row -->

        <!-- /.row -->

        <!-- START WIDGETS -->
                        
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-file-text fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">

                                <?php
                                    $query = "SELECT * FROM posts ";
                                    $result = mysqli_query($connection, $query);
                                    $posts_count = mysqli_num_rows($result);
                                ?>


                              <div class='huge'> <?php echo $posts_count; ?> </div>
                              <div>Posts</div>
                            </div>
                        </div>
                    </div>
                    <a href="posts.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-green">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-comments fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">

                                <?php
                                    $query = "SELECT * FROM comments ";
                                    $result = mysqli_query($connection, $query);
                                    $comments_count = mysqli_num_rows($result);
                                ?>

                             <div class='huge'><?php echo $comments_count; ?></div>
                              <div>Comments</div>
                            </div>
                        </div>
                    </div>
                    <a href="comments.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-yellow">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-user fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">

                            <?php
                                    $query = "SELECT * FROM users ";
                                    $result = mysqli_query($connection, $query);
                                    $users_count = mysqli_num_rows($result);
                                ?>

                             <div class='huge'><?php echo $users_count; ?></div>
                                <div> Users</div>
                            </div>
                        </div>
                    </div>
                    <a href="users.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6">
                <div class="panel panel-red">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-3">
                                <i class="fa fa-list fa-5x"></i>
                            </div>
                            <div class="col-xs-9 text-right">

                            <?php
                                $query = "SELECT * FROM categories ";
                                $result = mysqli_query($connection, $query);
                                $cat_count = mysqli_num_rows($result);
                            ?>

                             <div class='huge'><?php echo $cat_count; ?></div>
                                 <div>Categories</div>
                            </div>
                        </div>
                    </div>
                    <a href="categories.php">
                        <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

        <br>
        <br>
        <br>

        <!-- END WIDGETS -->

        <!-- /.row -->

<?php
    $query = "SELECT * FROM posts WHERE post_status = 'draft'; ";
    $result = mysqli_query($connection, $query);
    $draft_posts_count = mysqli_num_rows($result);
?>

<?php
    $query = "SELECT * FROM posts WHERE post_status = 'published'; ";
    $result = mysqli_query($connection, $query);
    $published_posts_count = mysqli_num_rows($result);
?>

<?php
    $query = "SELECT * FROM comments WHERE comment_status = 'approved'; ";
    $result = mysqli_query($connection, $query);
    $approved_comments_count = mysqli_num_rows($result);
?>

<?php
    $query = "SELECT * FROM comments WHERE comment_status = 'unapproved'; ";
    $result = mysqli_query($connection, $query);
    $unapproved_comments_count = mysqli_num_rows($result);
?>

<?php
    $query = "SELECT * FROM users WHERE user_role = 'admin'; ";
    $result = mysqli_query($connection, $query);
    $admin_count = mysqli_num_rows($result);
?>

<?php
    $query = "SELECT * FROM users WHERE user_role = 'subscriber'; ";
    $result = mysqli_query($connection, $query);
    $subscriber_count = mysqli_num_rows($result);
?>








        <div class="row">
            
            <script type="text/javascript">
              google.charts.load('current', {'packages':['bar']});
              google.charts.setOnLoadCallback(drawChart);

              function drawChart() {
                var data = google.visualization.arrayToDataTable([
                  ['Date', 'Total' , 'Unapproved' , 'Approved'],

                  <?php 

          $elements_title = ['Active Posts',  'Comments','Users', 'Categories'];
          $elements_count = [$posts_count ,  $comments_count, $users_count, $cat_count];

          // for($i = 0; $i < 4 ; $i++){

          //   echo  "[ '{$elements_title[$i]}' " . "," . " {$elements_count[$i]} ] ,";

          //         }

        echo "[" . " 'Posts' " . "," . " $posts_count " . "," .  "$draft_posts_count"  . "," .  "$published_posts_count" . "],";

        echo "[" . " 'Comments' " . "," . " $comments_count " . "," .  "$unapproved_comments_count"  . "," .  "$approved_comments_count" . "],";

        echo "[" . " 'Users' " . "," . " $users_count " . "," .  "$subscriber_count"  . "," .  "$admin_count" . "],";

        echo "[" . " 'Categories' " . "," . " $posts_count " . "," .  "0"  . "," .  "0" . "]";


                   ?>


                 // ['posts', 5],
                 // ['c', 10],
                 // ['u', 4],
                 // ['cat', 7],
                ]);

                var options = {
                  chart: {
                    title: '',
                    subtitle: '',
                  }
                };

                var chart = new google.charts.Bar(document.getElementById('columnchart_material'));

                chart.draw(data, google.charts.Bar.convertOptions(options));
              }

            </script>

                <div id="columnchart_material" style="width: 'auto'; height: 500px;"></div>

        </div>




    </div>
    <!-- /.container-fluid -->

</div>


<!-- Footer -->
<?php include "includes/admin_footer.php" ?>