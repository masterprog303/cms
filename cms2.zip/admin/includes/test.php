<?php 


if('$2y$12$uJSSwvBrWJFYrskU0hKjYO7nhDHmPP/JRYaQ9lEiwv8p.rExJ/77i' == '$2y$12$6JSkrZG7LY8CI7D59x9dKubUaRrylveDArk.vpngYUp/WCIKaNui2')
{
	echo "<h1>TRUE</h1>";
}
else
{
	echo "<h1>FALSE</h1>";
}

 ?>