<table class="table table-bordered table-hover">
    <thead>
        <tr>
            <th>Id</th>
            <th>Username</th>
           <!--  <th>Password</th> -->
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Image</th> 
            <th>Role</th>
            <th>Admin</th>
            <th>Subscriber</th>
            <th>Edit</th> 
            <th>Delete</th>
            
        </tr>
    </thead>
    <tbody>
        
        <?php 

            $query = "SELECT * FROM users ";

            $view_all_users_query = mysqli_query($connection, $query);

            if (!$view_all_users_query){
                
                die("Query Falied !" . mysqli_error($connection));
            
            }else{
               
               while($row = mysqli_fetch_assoc($view_all_users_query)){

                //echo "<pre>";  print_r($row); echo "</pre>"; 

                $user_id = $row['user_id'];
                $user_name = $row['user_name'];
                $user_password = $row['user_password'];
                $user_firstname = $row['user_firstname'];
                $user_lastname = $row['user_lastname'];
                $user_email = $row['user_email'];
                $user_image = $row['user_image'];
                $user_role = $row['user_role'];
                
                    echo "<tr>";
                    echo "<td>{$user_id}</td>";
                    echo "<td>{$user_name}</td>";
                    //echo "<td>{$user_password}</td>";
                    echo "<td>{$user_firstname}</td>";
                    echo "<td>{$user_lastname}</td>";
                    echo "<td>{$user_email}</td>";
                    echo "<td><img class='img-responsive' width='100' alt'{$user_name} src='../image/{$user_image}'></td>";
                    echo "<td>{$user_role}</td>";
                    echo "<td><a href='users.php?admin={$user_id}'> Admin </a></td>";
                    echo "<td><a href='users.php?subscriber={$user_id}'> Subscriber </a></td>";
                    echo "<td><a href='users.php?source=edit_user&p_id={$user_id}'> Edit </a></td>";
                    echo "<td><a href='users.php?delete={$user_id}'> Delete </a></td>";
                   
                    
                    echo "</tr>";


                }
            }

         ?>
    </tbody>
</table>

<?php


if(isset($_GET['admin'])){
  
    $the_user_id = $_GET['admin'];

    $query = "UPDATE users SET user_role = 'admin' WHERE user_id = {$the_user_id} ";

    $change_to_admin_query = mysqli_query($connection, $query);

    header("Location: users.php");

}

if(isset($_GET['subscriber'])){
  
    $the_user_id = $_GET['subscriber'];

    $query = "UPDATE users SET user_role = 'subscriber' WHERE user_id = {$the_user_id} ";

    $change_to_subscriber_query = mysqli_query($connection, $query);

    header("Location: users.php");

}


if(isset($_GET['delete'])){

    if(isset($_SESSION['user_role'])){

        if($_SESSION['user_role'] == 'admin'){

  
    
    $the_user_id = mysqli_escape_string($connection, $_GET['delete']);

    $query = "DELETE FROM users WHERE user_id = {$the_user_id} ";

    $delete_user_query = mysqli_query($connection, $query);

    //For Page Refresh After delete request !
    header("Location: users.php");
          }
    }


}

 ?>