<?php 

if(isset($_GET['p_id'])){
  $the_user_id = $_GET['p_id'];


/// end IF SET here to User the  ID in the two queries
$query = "SELECT * FROM users WHERE user_id = '{$the_user_id}'";
$select_user_by_id_query = mysqli_query($connection, $query);

confirm($select_user_by_id_query); 

   while($row = mysqli_fetch_assoc($select_user_by_id_query)){
      
      $user_id = $row['user_id'];
      $user_name = $row['user_name'];
      $user_password = $row['user_password'];
      $user_firstname = $row['user_firstname'];
      $user_lastname = $row['user_lastname'];
      $user_email = $row['user_email'];
      $user_image = $row['user_image'];
      $user_role = $row['user_role'];                       
}

          
if(isset($_POST['edit_user'])){
  
  $user_name = $_POST['user_name'];
  $user_firstname = $_POST['user_firstname'];
  $user_lastname = $_POST['user_lastname'];
  $user_password = $_POST['user_password'];
  $user_email = $_POST['user_email'];
  $user_role = $_POST['user_role'];


if(!empty($user_password)){

  $query = "SELECT user_password FROM users WHERE user_id = '{$the_user_id}' ";
  $get_user_password = mysqli_query($connection, $query);
  confirm($get_user_password);

  $row = mysqli_fetch_array($get_user_password);

  $db_user_password = $row['user_password'];

  if($db_user_password != $user_password){

    $hashed_password = password_hash($user_password, PASSWORD_BCRYPT, array('cost' => 10));
  }

  $query ="UPDATE users SET ";
  $query .= "user_name = '{$user_name}', "; 
  $query .= "user_firstname = '{$user_firstname}', ";
  $query .= "user_lastname = '{$user_lastname}', ";
  $query .= "user_password = '{$hashed_password}', "; 
  $query .= "user_email = '{$user_email}', "; 
  $query .= "user_role = '{$user_role}' "; 
  $query .= "WHERE user_name = '{$user_name}' ";

  $update_user_query = mysqli_query($connection, $query);

  confirm($update_user_query);

  echo " User Updated " . "<a href='users.php'>View Users </a>";  
}
         
}

}
else {  // If the user id is not present in the URL we redirect to the home page

        header("Location: index.php");
}


?>

<form action="" method="post" enctype="multipart/form-data">    

  <div class="form-group ">
    <label for="user_firstname">First Name</label>
    <input value="<?php echo $user_firstname; ?>" type="text" class="form-control" name="user_firstname">
  </div>
  <div class="form-group ">
    <label for="user_lastname">Last Name</label>
    <input value="<?php echo $user_lastname; ?>" type="text" class="form-control" name="user_lastname">
  </div>

   <div class="form-group">
    <label for="user_role">User Role</label>
    <select name="user_role" id="">

            <option value='<?php echo $user_role; ?>'><?php echo $user_role; ?></option>";

            <?php 

            if($user_role == 'admin'){

              echo "<option value='subscriber'>subscriber</option>";

            } else {

               echo "<option value='admin'>admin</option>";

            }
             

             ?>

     </select>
  </div>

  <div class="form-group">
     <label for="user_name">Username</label>
     <input value="<?php echo $user_name; ?>" type="text" class="form-control" name="user_name">
  </div>

  <div class="form-group">
      <label for="user_email">Email</label>
      <input value="<?php echo $user_email ; ?>" type="email" class="form-control" name="user_email">
  </div>

  <div class="form-group">
      <label for="user_password">Password</label>
      <input autocomplete="off" type="password" class="form-control" name="user_password">
  </div>
  

  <div class="form-group">
      <input class="btn btn-primary" type="submit" name="edit_user" value="Edit User">
  </div>


</form>

<!-- 
<div class="form-group">
    <label for="category">User Role</label>

    <select name="user_role" id="">
        
         <?php
/*
          $query = "SELECT * FROM users ";

          $select_user_role_query = mysqli_query($connection, $query);

          confirm($select_user_role_query);
    
          while ($row = mysqli_fetch_assoc($select_user_role_query)) {
    
              $user_id = $row['user_id'];
              $user_role = $row['user_role']; 

              echo "<option value='{$user_id}'>{$user_role}</option>";
          }
*/
          ?>

     </select>
  </div>
   -->