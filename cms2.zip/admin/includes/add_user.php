<?php 
	
	if(isset($_POST['create_user'])){

        $user_name = $_POST['user_name'];
        $user_firstname = $_POST['user_firstname'];
        $user_lastname = $_POST['user_lastname'];
        $user_password = $_POST['user_password'];
        $user_email = $_POST['user_email'];
        $user_role = $_POST['user_role'];

        //===================IMPORTANT==========================================
        // ============ PASSWORD CRYPTING TO MORE SECURE =======================

        // 1st Param of Password_hash() => $user_password
        // 2nd Param of Password_hash() => Algorithm
        $algo = PASSWORD_BCRYPT;

        // 3rd Param of password_hash() => array of options
        $salt = '';
        $cost = 10;
        $options = ['cost' => $cost];
        
        // Password_Hash
        $hashed_password = password_hash($user_password, $algo, $options);

        //======================================================================
/*
        $post_image = $_FILES['image']['name'];
        $post_image_temp = $_FILES['image']['tmp_name'];

      
        // Upload the Image to your Server 
        // move_uploaded_file(filename, destination)
        move_uploaded_file($post_image_temp, "../images/$post_image");

        //print_r($_FILES);
  
*/
        $query ="INSERT INTO users(
        		 					user_name, 
        		 					user_firstname, 
        		 					user_lastname, 
        		 					user_password, 
        		 					user_email, 
        		 					user_role ) ";

        $query .="VALUES (
        		 					'{$user_name}',
        		 					'{$user_firstname}',
        		 					'{$user_lastname}',
        		 		      '{$hashed_password}',
        		 					'{$user_email}',
        		 					'{$user_role}' ) ";

        $add_new_user_query = mysqli_query($connection, $query);

        confirm($add_new_user_query);

        echo "New User Created " . " " . "<a href='users.php'>View Users </a>";	
	}

?>


<form action="" method="post" enctype="multipart/form-data">    

  <div class="form-group ">
  	<label for="user_firstname">First Name</label>
  	<input type="text" class="form-control" name="user_firstname">
  </div>
  <div class="form-group ">
    <label for="user_lastname">Last Name</label>
    <input type="text" class="form-control" name="user_lastname">
  </div>

   <div class="form-group">
  	<label for="user_role">User Role</label>
    <select name="user_role" id="">
        <option value='subscriber'>Select Options</option>
        <option value='admin'>Admin</option>
        <option value='subscriber'>Subscriber</option>
     </select>
  </div>

<!--   
	<div class="form-group">
	<label for="post_image">User Image</label>
	<input type="file" class="form-control-file"  name="user_image">
 </div>
 -->
  <div class="form-group">
	 <label for="user_name">Username</label>
	 <input type="text" class="form-control" name="user_name">
  </div>

  <div class="form-group">
    <label for="user_email">Email</label>
    <input type="email" class="form-control" name="user_email">
  </div>

  <div class="form-group">
    <label for="user_password">Password</label>
    <input type="password" class="form-control" name="user_password">
  </div>
  

  <div class="form-group">
      <input class="btn btn-primary" type="submit" name="create_user" value="Add User">
  </div>


</form>
