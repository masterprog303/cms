<?php 


function escape($string){

global $connection;

return  mysqli_real_escape_string($connection, trim($string));
}


function insert_category(){

global $connection;

	if(isset($_POST['submit'])){

	    $cat_title = $_POST['cat_title'];

    //IMPORTANT VALIDATION 

    if($cat_title == "" || empty($cat_title)){

        echo "This field can't be Empty !";

    } else{

        $query = "INSERT INTO categories(cat_title) ";
        $query .= "VALUES ('$cat_title') ";

        $insert_new_category_query = mysqli_query($connection, $query);

        if (!$insert_new_category_query){

            die("Query Falied !" . mysqli_error($connection));
        
        }else{

            echo "New Category [ " . $cat_title . " ] Added";

        	}
    	}
	}
}



function find_all_categories(){

    global $connection;

     $query = "SELECT * FROM categories ORDER BY cat_id";

    $view_all_categories_query = mysqli_query($connection, $query);

    if (!$view_all_categories_query){
        
        die("Query Falied !" . mysqli_error($connection));
    
    }else{
       
       while($row = mysqli_fetch_assoc($view_all_categories_query)){
        $cat_id = $row['cat_id'];
        $cat_title = $row['cat_title'];

            echo "<tr>";
            echo "<th>{$cat_id}</th>";
            echo "<th>{$cat_title}</th>";
            echo "<th><a href='categories.php?edit={$cat_id}'>Edit</a></th>";
            echo "<th><a href='categories.php?delete={$cat_id}'>Delete</a></th>";
            echo "</tr>";

        }
    }

}


function delete_category(){

global $connection;

 if(isset($_GET['delete'])){

    $del_cat_id = $_GET['delete'];

    $query = "DELETE FROM categories ";
    $query .= "WHERE cat_id = {$del_cat_id} ";

    $delete_cat_query = mysqli_query($connection, $query);

    //For Page Refresh After delete request !
    header("Location: categories.php");

}

}


function confirm($result){

global $connection;

if(!$result){  
    die("Query Falied !" . mysqli_error($connection)); 
}
}

function users_online(){

if(isset($_GET['users_online'])){

global $connection;

if(!$connection){

    session_start();
    include ("../includes/db.php");

    $session = session_id();
    $time = time();
    $time_out_in_seconds = 10;
    $time_out = $time - $time_out_in_seconds;


    $query = "SELECT * FROM users_online WHERE session = '$session' ";
    $result = mysqli_query($connection, $query);
    $count = mysqli_num_rows($result);

    if($count == null){

        $query1= "INSERT INTO users_online(session, session_time) ";
        $query1 .= "VALUES ('$session','$time')"; 
        $result1 = mysqli_query($connection, $query1);

    } else {

        $query2 = "UPDATE users_online ";
        $query2 .= "SET session_time = '$time' "; 
        $query2 .= "WHERE session = '$session' "; 
        $result2 = mysqli_query($connection, $query2);
    }

    $query3 = "SELECT * FROM users_online ";
    $query3 .= "WHERE session_time > '$time_out' "; 
    $users_online_query = mysqli_query($connection, $query3);
    
    echo $count_users = mysqli_num_rows($users_online_query);

    // $query4 ="DELETE FROM users_online WHERE session_time < $time_out ";
    // $delete_offline_users_query = mysql_query($connection, $query4);

}

} //GET request

}

users_online();

?>