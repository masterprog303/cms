$(document).ready(function(){

//CK EDITOR CLASSIC
ClassicEditor
	.create( document.querySelector( '#editor' ) )
	.then( editor => {
	        console.log( editor );
	} )
	.catch( error => {
	        console.error( error );
	} );


//selectAllBoxes => checkBoxes

$('#selectAllBoxes').click(function(event){

	if(this.checked){

		$('.checkBoxes').each(function(){

			this.checked = true;
		});
	}

	else {

		$('.checkBoxes').each(function(){

			this.checked = false;
		});

	}

});

// Loader Screen Script

// var div_box = "<div id='load-screen'><div id='loading'></div></div>";

// $("body").prepend("<div id='load-screen'><div id='loading'></div></div>");

// //$("body").prepend(div_box);

// $('#load-screen').delay(700).fadeOut(600, function(){
// 	$(this).remove();
// });


function loadUsersOnline() {

	$.get("admin_functions.php?users_online=result", function(data){

		$(".users-online").text(data);

	}); 

}

setInterval(function(){

	loadUsersOnline();

} , 500);



$("#mastertog").click(function() {
  $('#cmstatus').toggleClass('greeened');
});




});