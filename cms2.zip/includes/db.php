<?php 

// Better Way to Connect 
$db['db_host'] = "localhost";
$db['db_user'] = "root";
$db['db_pass'] = "";
$db['db_name'] = "cms";

// convert all data to CONST

foreach ($db as $key => $value) {
	
	define(strtoupper($key), $value);
}


$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$connection){
	die("Connection to DB Failed" . mysqli_error($connection));
}
// else{
// 	echo "DB connected !";
// }


/* 

//Easy Way to Connect

$host = "localhost";
$user = "root";
$pass = "";
$name = "cms";

$connection = mysqli_connect($host, $user, $pass, $name);

if (!$connection){
	die("Connection to DB Failed" . mysqli_error($connection));
}
else{
	echo "DB connected !";
}

*/



?>