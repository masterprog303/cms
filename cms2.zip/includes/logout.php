<?php 

session_start();

echo "You Are Logging out " . $_SESSION['user_name'];

$_SESSION['user_name'] = null;
$_SESSION['user_firstname'] = null;
$_SESSION['user_lastname'] = null;
$_SESSION['user_role'] = null;

//session_unset();

//session_destroy();

header("Location: ../index.php ");

?>