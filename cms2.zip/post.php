<!--Connect To database-->
<?php include "includes/db.php" ?>

<!-- Header -->
<?php include "includes/header.php" ?>

<!-- Navigation -->

<?php include "includes/navigation.php" ?>

<!-- Page Content -->
<div class="container">

 <!-- Start row -->
<div class="row">

    <!-- Blog Entries Column -->
    <div class="col-md-8">

<?php

if(isset($_GET['p_id'])){

$the_post_id = $_GET['p_id'];

$query = "UPDATE posts SET post_views_count = post_views_count + 1 ";
$query .= "WHERE post_id = $the_post_id ";
$increment_post_views_count_query = mysqli_query($connection, $query);

if (!$increment_post_views_count_query){
    die("Query Falied !" . mysqli_error($connection));
}

$query = " SELECT * FROM posts WHERE post_id = '$the_post_id' ";

$select_post_query = mysqli_query($connection, $query);

while($row = mysqli_fetch_assoc($select_post_query)) {
    
    //$post_id = $row['post_id'];
    $post_title = $row['post_title'];
    $post_user = $row['post_user'];
    $post_date = $row['post_date'];
    $post_image = $row['post_image'];
    $post_content = $row['post_content'];


?>
                
        <h1 class="page-header">
            Page Heading
            <small>Secondary Text</small>
        </h1>



        <!-- First Blog Post -->
<?php 
 
if(isset($_SESSION['user_role'])){

    if(isset($_GET['p_id'])){

    $the_post_id = $_GET['p_id'];

    
    echo  "<a href='admin/posts.php?source=edit_post&p_id={$the_post_id}' class=''><span class='btn btn-primary'>Edit Post</span></a>";

    echo "  ";

    echo  "<a href='admin/posts.php?delete={$the_post_id}' class=''><span class='btn btn-danger'>Delete Post</span></a>";
    
    }
}



 ?>

 <?php  //echo "<pre>"; print_r($_SESSION); echo "</pre>"; ?>


        <h2>
            <a href="#"> <?php echo $post_title; ?> </a>
        </h2>

         <?php 
              
              $query = "SELECT user_name,user_id FROM users WHERE user_id = '$post_user' ";
              $select_users_query = mysqli_query($connection, $query);
              $row = mysqli_fetch_assoc($select_users_query);
              $post_user_id = $row['user_id'];
              $post_user_name = $row['user_name']; 

    ?>

    
        <p class="lead">
            by <a href="post_user.php?user=<?php echo $post_user; ?>"> <?php echo $post_user_name; ?> </a>
        </p>
        <p><span class="glyphicon glyphicon-time"></span> Posted on <?php echo $post_date; ?> </p>
        <hr>
        <img class="img-responsive" src="images/<?php echo $post_image; ?>" alt="">
        <hr>
        <p> <?php echo $post_content; ?> </p>
        

        <hr>
            
            <?php }}

            else {

                header("Location: index.php");
            }


             ?>

        <!-- Post Comments section Column -->
        <?php include "comments.php" ?>


    </div>

    <!-- Blog Sidebar Widgets Column -->
    <?php include "includes/sidebar.php" ?>

</div>
<!-- /.row -->

<hr>

<!-- Footer -->
<?php include "includes/footer.php" ?>